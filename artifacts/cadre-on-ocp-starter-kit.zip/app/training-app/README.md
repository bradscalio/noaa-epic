# Training App (Placeholder)

This folder is a placeholder for a lightweight UI that launches RHODS notebooks and Tekton pipelines, and shows results.
Suggested stack:
- React front-end (OpenShift OAuth)
- Small Flask/FastAPI to call cluster APIs
- Use Tekton and RHODS CRDs to create runs and workbenches
